//
//  tableRow.swift
//  CookBook
//
//  Created by Алексеев on 04.04.2022.
//

import WatchKit

class tableRow: NSObject {
    @IBOutlet weak var RecipeIconLabel: WKInterfaceLabel!
    
    @IBOutlet weak var RecipeNameLabel: WKInterfaceLabel!
}
